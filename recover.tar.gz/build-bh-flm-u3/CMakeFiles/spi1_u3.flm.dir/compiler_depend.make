# Empty compiler generated dependencies file for spi1_u3.flm.
# This may be replaced when dependencies are built.
