# Empty dependencies file for spi_combo.flm.
# This may be replaced when dependencies are built.
