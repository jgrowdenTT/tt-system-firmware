# Empty compiler generated dependencies file for spi1.flm.
# This may be replaced when dependencies are built.
